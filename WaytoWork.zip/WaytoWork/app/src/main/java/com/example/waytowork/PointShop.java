package com.example.waytowork;


import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

public class PointShop extends AppCompatActivity {

   protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
       setContentView(R.layout.pointshop);

   }
}
