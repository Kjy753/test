package com.example.waytowork;

public class MainData {

     String iv_item_kat;//이미지는 int값
     String tv_start_po;
     String tv_end_po;
     String tv_content;

    public String getIv_item_kat() {
        return iv_item_kat;
    }

    public void setIv_item_kat(String iv_item_kat) {
        this.iv_item_kat = iv_item_kat;
    }

    public String getTv_start_po() {
        return tv_start_po;
    }

    public void setTv_start_po(String tv_start_po) {
        this.tv_start_po = tv_start_po;
    }

    public String getTv_end_po() {
        return tv_end_po;
    }

    public void setTv_end_po(String tv_end_po) {
        this.tv_end_po = tv_end_po;
    }

    public String getTv_content() {
        return tv_content;
    }

    public void setTv_content(String tv_content) {
        this.tv_content = tv_content;
    }
}